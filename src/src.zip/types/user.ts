export interface User {
  userId: number;
  name: string;
  surname: string;
  date: string;
  role: string;
}
