export interface Lesson {
  lessonId: number;
  title: string;
  teacher: string;
  date: string;
  students: Object[];
  description: string;
}
