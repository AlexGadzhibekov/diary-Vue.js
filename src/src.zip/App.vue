<template>
  <div class="back">
    <router-view></router-view>
  </div>
</template>

<script setup lang="ts"></script>

<style scoped>
.back {
  width: 100vw;
  min-height: 100vh;
  background-color: #181818;
}
</style>
