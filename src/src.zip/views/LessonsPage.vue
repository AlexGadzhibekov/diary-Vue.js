<template>
  <div class="container">
    <header-default></header-default>
    <router-view></router-view>
  </div>
</template>

<script setup lang="ts"></script>

<style scoped></style>
