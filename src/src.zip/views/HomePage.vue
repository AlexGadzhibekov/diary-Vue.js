<template>
  <div class="container">
    <header-default></header-default>
    <h1>Главная</h1>
  </div>
</template>

<script setup lang="ts"></script>

<style scoped></style>
